package Orders;

import CoursesOperate.CourseSelectOperate;

public class SelectCourse {
    public static void selectCourse(String[] orderArgs) {
        CourseSelectOperate.selectCourse(orderArgs[0]);
    }
}
